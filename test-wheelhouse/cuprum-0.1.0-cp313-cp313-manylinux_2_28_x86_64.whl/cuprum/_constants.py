"""Internal constants for the cuprum package."""

from __future__ import annotations

PACKAGE_NAME = "cuprum"
